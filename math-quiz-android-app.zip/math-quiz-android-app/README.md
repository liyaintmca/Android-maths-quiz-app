# math-quiz-android-app
Simple Math Quiz app. User has 30 seconds timer running, user has to solve maximum problems in 30 seconds. Score is recorded.
Download repository and extract zip file. Open project in Android Studio to run the file
